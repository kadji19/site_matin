<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>@yield('title') · Administration</title>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('admin/css/admin.css') }}">
</head>
<body>
@php
$nav = [
['admin.faqs.index','FAQ','faq','admin.faqs.*'],    
['admin.trust-items.index','Bandeau de réassurance','trust','admin.trust-items.*'],
['admin.steps.index','Comment ça marche','steps','admin.steps.*'],
['admin.features.index','Fonctionnalités','features','admin.features.*'],
['admin.screenshots.index','Captures d’écran','screens','admin.screenshots.*'],
['admin.voice-commands.index','Commandes vocales','voice','admin.voice-commands.*'],
['admin.plans.index','Tarifs','trust','admin.plans.*'],
['admin.security-points.index','Sécurité et vie privée','security','admin.security-points.*'],
['admin.settings.edit','Réglages','settings','admin.settings.*'],
['admin.contact-messages.index', 'Messages', 'mail', 'admin.contact-messages.*'],
['admin.deletion-requests.index', 'Demandes de suppression', 'trash', 'admin.deletion-requests.*'],
];
@endphp
<div class="app">
<nav class="side" aria-label="Sections">
<div class="brand">Administration</div>
@foreach($nav as [$route, $label, $icon, $pattern])
<a href="{{ route($route) }}" @class(['on' => request()->routeIs($pattern)])>@include('backend.partials.icon', ['name' => $icon]){{ $label }}</a>
@endforeach
</nav>
<div class="main">
<header class="top">
<h1>@yield('title')</h1>
<div>
<a class="btn ghost site" href="{{ route('home') }}" target="_blank" rel="noopener">@include('backend.partials.icon', ['name' => 'external']) Voir le site</a>
<form method="POST" action="{{ route('logout') }}">@csrf
<button class="btn ghost out" type="submit">@include('backend.partials.icon', ['name' => 'logout']) Se déconnecter</button></form>
</div>
</header>
<main class="page">
@if(session('success'))<p class="ok" role="status">{{ session('success') }}</p>@endif
@yield('content')
</main>
</div>
</div>
</body>
</html>
