@extends('backend.layouts.app')
@section('title', 'Message')
@section('content')
<div class="head">
<a class="btn ghost" href="{{ route('admin.contact-messages.index') }}">Retour aux messages</a>
<span @class(['badge', 'off' => $contactMessage->handled_at])>{{ $contactMessage->handled_at ? 'Traité' : 'Nouveau' }}</span>
</div>
<div class="card">
<p><b>De :</b> {{ $contactMessage->name }} ({{ $contactMessage->email }})</p>
<p><b>Sujet :</b> {{ \App\Models\ContactMessage::SUBJECTS[$contactMessage->subject] ?? $contactMessage->subject }}</p>
<p><b>Reçu le :</b> {{ $contactMessage->created_at->locale('fr')->translatedFormat('j F Y à H:i') }}</p>
<hr class="sep">
<p style="white-space:pre-line">{{ $contactMessage->message }}</p>
<hr class="sep">
<div class="bar">
<a class="btn" href="mailto:{{ $contactMessage->email }}">@include('backend.partials.icon', ['name' => 'mail']) Répondre par e-mail</a>
<form method="POST" action="{{ route('admin.contact-messages.handled', $contactMessage) }}">@csrf @method('PATCH')
<button class="btn ghost" type="submit">{{ $contactMessage->handled_at ? 'Rouvrir' : 'Marquer comme traité' }}</button>
</form>
</div>
</div>
@endsection